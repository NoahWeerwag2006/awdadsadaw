# fut20-web-app 

Tampermonkey scripts for FUT 20 autobuyer functionality.

ONLY for player search (non consumables and other shit)!

Works only on English language of FUT 20 web app!

The software is provided "as is" without warranty of any kind, either express or implied. Use it at your own risk.
